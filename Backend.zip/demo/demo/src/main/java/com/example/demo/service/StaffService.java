package com.example.demo.service;

import com.example.demo.model.Staff;
import com.example.demo.repository.StaffRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffService {

    private final StaffRepository repository;

    public StaffService(StaffRepository repository) {
        this.repository = repository;
    }

    public List<Staff> getAll() {
        return repository.findAll();
    }

    public Staff save(Staff staff) {
        return repository.save(staff);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public Staff update(String id, Staff staff) {
        staff.setId(id);
        return repository.save(staff);
    }
}