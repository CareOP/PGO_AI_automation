package com.example.demo.controller;

import com.example.demo.model.Medicine;
import com.example.demo.repository.MedicineRepository;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@RestController
@RequestMapping("/api/medicines")
@CrossOrigin(origins = "http://localhost:5173")
public class MedicineController {

    @Autowired
    private MedicineRepository medicineRepository;

    // ✅ GET
    @GetMapping
    public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

    // ✅ POST
    @PostMapping
    public Medicine addMedicine(@RequestBody Medicine medicine) {
        return medicineRepository.save(medicine);
    }

    // ✅ DELETE
    @DeleteMapping("/{id}")
    public void deleteMedicine(@PathVariable String id) {
        medicineRepository.deleteById(id);
    }

    // ✅ UPDATE
    @PutMapping("/{id}")
    public Medicine updateMedicine(@PathVariable String id,
                                   @RequestBody Medicine medicine) {
        medicine.setId(id);
        return medicineRepository.save(medicine);
    }
}