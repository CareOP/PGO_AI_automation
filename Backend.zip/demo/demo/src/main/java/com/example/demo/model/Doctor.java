package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;

@Document(collection = "doctors")
@Data
public class Doctor {

    @Id
    private String id;

    private String name;
    private String specialization;
    private String hospital;
}