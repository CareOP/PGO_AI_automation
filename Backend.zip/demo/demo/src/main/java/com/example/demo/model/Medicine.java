package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import lombok.Data;

@Document(collection = "medicines")
@Data
public class Medicine {

    @Id
    private String id;

    private String name;
    private int stock;
    private double price;
}