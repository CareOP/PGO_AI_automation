package com.example.demo.controller;

import com.example.demo.model.Staff;
import com.example.demo.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
@CrossOrigin(origins = "http://localhost:5173")
public class StaffController {

    @Autowired
    private StaffService staffService;

    // GET all staff
    @GetMapping
    public List<Staff> getAllStaff() {
        return staffService.getAll();
    }

    // CREATE staff
    @PostMapping
    public Staff createStaff(@RequestBody Staff staff) {
        return staffService.save(staff);
    }

    // UPDATE staff
    @PutMapping("/{id}")
    public Staff updateStaff(@PathVariable String id, @RequestBody Staff staff) {
        return staffService.update(id, staff);
    }

    // DELETE staff
    @DeleteMapping("/{id}")
    public void deleteStaff(@PathVariable String id) {
        staffService.delete(id);
    }
}