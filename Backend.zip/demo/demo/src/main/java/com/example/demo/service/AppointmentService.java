package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.repository.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    private final AppointmentRepository repository;

    public AppointmentService(AppointmentRepository repository) {
        this.repository = repository;
    }

    public List<Appointment> getAll() {
        return repository.findAll(); // 🔥 FETCH FROM MONGODB
    }

    public Appointment save(Appointment appointment) {
        return repository.save(appointment); // 🔥 SAVE TO MONGODB
    }
}