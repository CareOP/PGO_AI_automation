package com.example.demo.service;

import com.example.demo.model.Patient;
import com.example.demo.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository repository;

    public PatientService(PatientRepository repository) {
        this.repository = repository;
    }

    public List<Patient> getAll() {
        return repository.findAll();
    }

    public Patient save(Patient patient) {
        return repository.save(patient);
    }

    public void delete(String id) {
        repository.deleteById(id);
    }

    public Patient update(String id, Patient patient) {
        patient.setId(id);
        return repository.save(patient);
    }
}